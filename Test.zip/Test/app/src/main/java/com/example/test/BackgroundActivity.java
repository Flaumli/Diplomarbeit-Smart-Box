package com.example.test;


import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.StrictMode;
import android.view.View;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class BackgroundActivity extends AppCompatActivity {
    private Connection connection = null;
    private SQLiteDatabase sqliteDatabase;
    public Cursor cursor = sqliteDatabase.rawQuery(database, null);
   public String columnIndexWort = String.valueOf(cursor.getColumnIndex("Wort"));
   public int columnIndexID = cursor.getColumnIndex("ID");



    private static String ip = "10.0.2.2";// Die Host IP der Datenbank, da wir lokal alles auf einem Computer laufen ist sie 10.0.2.2
    private static String port = "1433";// Der Port auf dem der SQL Server läuft
    private static String Classes = "net.sourceforge.jtds.jdbc.Driver";// Der treiber damit das Programm funktioniert, ist in gradle.kts angegeben
    private static String database = "WörterBank";// Der Datenbank name
    private static String username = "abc";// Der Benutzername zur Verbindung zu der Datenbank
    private static String password = "123";// Das Passwort zur Verbindung zu der Datenbank
    private static String url = "jdbc:jtds:sqlserver://"+ip+":"+port+"/"+database; // die URL der Seite





    public void start(View view) {
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.INTERNET}, PackageManager.PERMISSION_GRANTED);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {
            Class.forName(Classes);
            connection = DriverManager.getConnection(url, username,password);
            Toast.makeText(this, "Connected", Toast.LENGTH_SHORT).show();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(this, "Class fail", Toast.LENGTH_SHORT).show();
        } catch (SQLException e) {
            e.printStackTrace();
            Toast.makeText(this, "could not connect", Toast.LENGTH_SHORT).show();
        }



        if (cursor.moveToFirst()){
            while(!cursor.isAfterLast()){
                String Wort = cursor.getString(Integer.parseInt(columnIndexWort));
                String ID = String.valueOf(cursor.getInt(columnIndexID));
                Intent IDverweis = new Intent(BackgroundActivity.this, ControlActivity.class);
                IDverweis.putExtra("ID", ID);
                startActivity(IDverweis);
                Intent Wortverweis = new Intent(BackgroundActivity.this, ControlActivity.class);
                Wortverweis.putExtra("Wort", Wort);
                startActivity(Wortverweis);
            }
        }
        cursor.close();
    }
}